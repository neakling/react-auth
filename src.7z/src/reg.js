import { Link } from "react-router-dom";

const Reg = () => {
    return (
        <div>
            <h2>REG page</h2>
            <p>
                <Link to="/login">123123</Link>
            </p>
        </div>
    );
};
export default Reg;
