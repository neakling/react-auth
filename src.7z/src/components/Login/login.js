import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./login.css";
import { Button, Box } from "@mui/material";
import { purple, blue } from "@mui/material/colors";
import { styled } from "@mui/material/styles";

const Register = styled(Button)({
    textTransform: "none",
    fontSize: 16,
    fontFamily: ['"Segoe UI"'],
    backgroundColor: blue[400],
    width: 150,
});

const LoginButton = styled(Button)(({ theme }) => ({
    color: theme.palette.getContrastText(purple[500]),
    backgroundColor: purple[400],
    "&:hover": {
        backgroundColor: purple[700],
    },
    textTransform: "none",
    fontSize: 16,
    fontFamily: ['"Segoe UI"'],
    width: 150,
}));

const Login = () => {
    const [username, setUsername] = useState();
    const [password, setPassword] = useState();
    return (
        <div className="App">
            <div className="auth-block">
                <div className="block">
                    <h1 className="log-in">Login Page</h1>
                    <form>
                        <input
                            className="pass"
                            type="text"
                            align="center"
                            placeholder="Username"
                            onChange={(e) => setUsername(e.target.value)}
                        />
                        <input
                            className="pass"
                            type="password"
                            align="center"
                            placeholder="Password"
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <div className="buttons">
                            <Box sx={{ "& button": { m: 1 } }}>
                                <LoginButton type="submit" variant="contained">
                                    Login
                                </LoginButton>
                                <Register variant="contained">
                                    <Link to="/register">Register</Link>
                                </Register>
                            </Box>
                        </div>
                        <div className="forgot-password">
                            <p>Forgot password?</p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
};
export default Login;
